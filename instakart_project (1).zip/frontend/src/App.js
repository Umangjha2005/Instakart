import React from 'react';

function App() {
  return (
    <div className="App">
      <h1>Welcome to InstaKart!</h1>
      {/* Add your components here */}
    </div>
  );
}

export default App;
